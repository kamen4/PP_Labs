package com.company;

import java.util.Arrays;
import java.util.Comparator;

public class Main {

    public static void main(String[] args) {
        Student student1 = new Student("John", 20, "Male", 70.5, "Computer Science", 2, "A");
        Student student2 = new Student("Alice", 22, "Female", 65.2, "Mathematics", 3, "B");
        Student student3 = new Student("Bob", 19, "Male", 75.0, "Physics", 1, "C");

        Student[] students = {student1, student2, student3};

        // Сортировка по возрасту
        Arrays.sort(students);

        for (Student student : students) {
            System.out.println(student.toString());
        }
    }
}
