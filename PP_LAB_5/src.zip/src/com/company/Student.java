package com.company;

public class Student extends Man implements Comparable<Student> {
    private String faculty;
    private int course;
    private String group;

    public Student(String name, int age, String gender, double weight, String faculty, int course, String group) {
        super(name, age, gender, weight);
        this.faculty = faculty;
        this.course = course;
        this.group = group;
    }

    public void setAge(int age) {
        super.setAge(age);
    }

    public void setWeight(double weight) {
        super.setWeight(weight);
    }

    public void nextCourse() {
        course++;
    }

    public void changeGroup(String group) {
        this.group = group;
    }

    @Override
    public int compareTo(Student student) {
        // Реализация сравнения по возрасту
        return Integer.compare(getAge(), student.getAge());
    }

    @Override
    public String toString() {
        return "Name: " + getName() +
                ", Age: " + getAge() +
                ", Gender: " + getGender() +
                ", Weight: " + getWeight() +
                ", Faculty: " + faculty +
                ", Course: " + course +
                ", Group: " + group;
    }
}
